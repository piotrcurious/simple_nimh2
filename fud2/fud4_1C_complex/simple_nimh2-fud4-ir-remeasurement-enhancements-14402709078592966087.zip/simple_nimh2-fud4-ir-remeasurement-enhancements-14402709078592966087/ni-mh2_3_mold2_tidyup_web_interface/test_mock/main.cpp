#include <iostream>
#include <vector>
#include <cstring>
#include <cmath>
#include <iomanip>
#include <stdarg.h>
#include <assert.h>
#include <algorithm>

#include "dummy_esp32.h"

// Math helpers
using std::isnan;
using std::isfinite;
using std::min;
using std::max;

MockSerial Serial;
unsigned long mock_millis = 0;

// Redirect definitions.h includes
#define SPI_h
#define Arduino_h
#define WiFi_h
#define Adafruit_SHT4x_h
#define ADC_CONTINUOUS_H
#define ESP_ADC_CAL_H
#define ADC_H
#define WEBSERVER_H

#include "../ni-mh2_3_mold2_tidyup_web_interface/adc_dma.h"

// We need to include SystemDataManager.h with private members accessible
#define private public
#include "../ni-mh2_3_mold2_tidyup_web_interface/SystemDataManager.h"
#undef private

#include "../ni-mh2_3_mold2_tidyup_web_interface/definitions.h"
#include "../ni-mh2_3_mold2_tidyup_web_interface/internal_resistance.h"
#include "../ni-mh2_3_mold2_tidyup_web_interface/AdvancedPolynomialFitter.hpp"

// Hardware stubs that would normally be in .ino
void applyDuty(uint32_t duty);
void getThermistorReadings(double& temp1, double& temp2, double& tempDiff, float& t1_millivolts, float& voltage, float& current);
float estimateCurrent(int duty);
int estimateDutyCycleForCurrent(float target);

// Physics Simulation
struct BatterySim {
    float voltage = 1.15f;
    float unloaded_voltage = 1.25f;
    float temp = 22.0f;
    float ambient = 22.0f;
    float soc = 0.05f;
    float internal_resistance = 0.15f;
    float capacity_ah = 2.0f;

    // Non-linear duty-to-current mapping
    float getCurrent(int duty) {
        if (duty < 20) return 0.0f;
        float normalized = (float)(duty - 20) / 235.0f;
        return 2.5f * (normalized * normalized);
    }

    void update(float dt_s, int duty) {
        float current = getCurrent(duty);
        soc += (current * dt_s) / (capacity_ah * 3600.0f);

        float base_v = 1.2f + 0.15f * std::pow(soc, 0.5f);
        if (soc > 0.9f) base_v += (soc - 0.9f) * 4.0f;

        float current_ir = internal_resistance * (1.0f + std::max(0.0f, (float)std::abs(0.5f - soc) * 0.5f));
        unloaded_voltage = base_v;
        voltage = base_v + current * current_ir;

        float efficiency = 1.0f;
        if (soc > 0.8f) efficiency = 1.0f - (soc - 0.8f) * 2.0f;
        if (efficiency < 0) efficiency = 0;
        float P_heat = current * current * current_ir + current * voltage * (1.0f - efficiency);

        float dT = (P_heat * dt_s) / (DEFAULT_CELL_MASS_KG * DEFAULT_SPECIFIC_HEAT);
        float cooling = (temp - ambient) * 0.05f * dt_s;
        temp += dT - cooling;
    }
};
BatterySim sim;

// Global variables from .ino
volatile float voltage_mv = 1000.0f;
volatile float current_ma = 0.0f;
float MEASURABLE_CURRENT_THRESHOLD = 0.005f;
volatile double mAh_charged = 0.0;
volatile bool resetAh = false;
volatile uint32_t mAh_last_time = 0;
uint32_t dutyCycle = 0;
bool isCharging = false;
volatile AppState currentAppState = APP_STATE_IDLE;
DisplayState currentDisplayState = DISPLAY_STATE_IDLE;
unsigned long lastPlotUpdateTime = 0;
unsigned long lastChargingHouseTime = 0;
const int pwmPin = 19;
double THERMISTOR_1_OFFSET = 0.0;

void applyDuty(uint32_t duty) { dutyCycle = duty; }

void getThermistorReadings(double& temp1, double& temp2, double& tempDiff, float& t1_millivolts, float& voltage, float& current) {
    SystemData d = systemData.getData();
    temp1 = d.ambient_temp_c;
    temp2 = d.battery_temp_c;
    tempDiff = d.temp_diff_c;
    t1_millivolts = 0;
    voltage = d.battery_voltage_v;
    current = d.charge_current_a;
    voltage_mv = voltage * 1000.0f;
    current_ma = current * 1000.0f;
}

// ADC DMA Stubs for SystemDataManager.cpp
static uint32_t mock_sample_count = 0;
void getAdcSnapshot(AdcChannelIndex idx, AdcSnapshot &snapshot) {
    snapshot.count = mock_sample_count;
    float val_mv = 0;
    if (idx == ADC_IDX_CURRENT) {
        val_mv = sim.getCurrent((int)dutyCycle) * CURRENT_SHUNT_RESISTANCE * 1000.0f + systemData.getCurrentZeroOffsetMv();
    } else if (idx == ADC_IDX_VOLTAGE) {
        val_mv = (dutyCycle == 0 ? sim.unloaded_voltage : sim.voltage) * 1000.0f;
    } else if (idx == ADC_IDX_THERM1) {
        val_mv = 1500.0f;
    } else if (idx == ADC_IDX_THERM_VCC) {
        val_mv = 3300.0f;
    }
    snapshot.sum = (uint64_t)val_mv * snapshot.count;
}
uint32_t calculateSnapshotAverage(const AdcSnapshot &old_s, const AdcSnapshot &new_s) {
    uint32_t d_count = new_s.count - old_s.count;
    if (d_count == 0) return (uint32_t)(new_s.sum / (new_s.count ? new_s.count : 1));
    return (uint32_t)((new_s.sum - old_s.sum) / d_count);
}
float snapshotToMillivolts(AdcChannelIndex idx, uint32_t avg_raw) {
    return (float)avg_raw;
}
void setupAdcDma() {}
void processAdcDma() {}

SHT4xSensor::SHT4xSensor() : _temperature(0), _humidity(0) {}
bool SHT4xSensor::begin() { return true; }
void SHT4xSensor::read() { _temperature = sim.temp; _humidity = 50.0f; }

SystemDataManager::SystemDataManager(SHT4xSensor& sht4, int therm1Pin, int vccPin, double therm1Offset)
    : _sht4(sht4), _therm1Pin(therm1Pin), _vccPin(vccPin), _therm1Offset(therm1Offset), _currentZeroOffsetMv(75.0f) {
    _dataMutex = (SemaphoreHandle_t)1;
}
void SystemDataManager::begin() {}
void SystemDataManager::update() {
    static uint32_t last_m = 0;
    uint32_t now = mock_millis;
    if (last_m == 0) last_m = now;
    float dt_h = (float)(now - last_m) / 3600000.0f;
    mAh_charged += (sim.getCurrent((int)dutyCycle) * 1000.0f * dt_h);
    last_m = now;
    processAdcSnapshots();
}
void SystemDataManager::processAdcSnapshots() {
    AdcSnapshot currentSnap;
    getAdcSnapshot(ADC_IDX_CURRENT, currentSnap);
    uint32_t avgRawCurrent = calculateSnapshotAverage(_lastSnapshots[ADC_IDX_CURRENT], currentSnap);
    _lastSnapshots[ADC_IDX_CURRENT] = currentSnap;
    _currentData.current_mv = snapshotToMillivolts(ADC_IDX_CURRENT, avgRawCurrent);
    _currentData.charge_current_a = std::max(0.0f, (_currentData.current_mv - _currentZeroOffsetMv) / (CURRENT_SHUNT_RESISTANCE * 1000.0f));
    _currentData.current_sample_count = currentSnap.count;

    getAdcSnapshot(ADC_IDX_VOLTAGE, currentSnap);
    uint32_t avgRawVoltage = calculateSnapshotAverage(_lastSnapshots[ADC_IDX_VOLTAGE], currentSnap);
    _lastSnapshots[ADC_IDX_VOLTAGE] = currentSnap;
    _currentData.battery_voltage_v = snapshotToMillivolts(ADC_IDX_VOLTAGE, avgRawVoltage) / 1000.0f;

    _currentData.ambient_temp_c = sim.ambient;
    _currentData.battery_temp_c = sim.temp;
    _currentData.temp_diff_c = _currentData.battery_temp_c - _currentData.ambient_temp_c;
    _currentData.mah_charged = (float)mAh_charged;
    _currentData.last_update_ms = mock_millis;
}
SystemData SystemDataManager::getData() { return _currentData; }
void SystemDataManager::resetMah() { mAh_charged = 0; }
void SystemDataManager::setCurrentZeroOffsetMv(float mv) { _currentZeroOffsetMv = mv; }
float SystemDataManager::getCurrentZeroOffsetMv() { return _currentZeroOffsetMv; }

SHT4xSensor sht4Sensor;
SystemDataManager systemData(sht4Sensor, 36, 35, 0.0);
CurrentModel currentModel;

#define private public
#include "../ni-mh2_3_mold2_tidyup_web_interface/home_screen.h"
#undef private
HomeScreen homeScreen;

WebServer server;

#include "../ni-mh2_3_mold2_tidyup_web_interface/charging.h"
#include "../ni-mh2_3_mold2_tidyup_web_interface/logging.h"
#include "../ni-mh2_3_mold2_tidyup_web_interface/graphing.h"

// Manually bring in parts of .ino for testing model build
volatile BuildModelPhase buildModelPhase = BuildModelPhase::Idle;
int buildModelDutyCycle = 0;
unsigned long buildModelLastStepTime = 0;
float mock_calibrationSum = 0;
float mock_calibrationMax = 0;
int mock_calibrationCount = 0;
uint32_t mock_lastKnownSampleCount = 0;
float mock_noiseFloorMv = 0;
float noiseFloorMv = 0;
std::vector<float> mock_dutyCycles;
std::vector<float> mock_currents;

void buildCurrentModelStep() {
    const unsigned long now = millis();
    switch (buildModelPhase) {
        case BuildModelPhase::Idle:
            mock_dutyCycles.clear(); mock_currents.clear();
            applyDuty(0);
            buildModelLastStepTime = now;
            buildModelPhase = BuildModelPhase::Settle;
            std::cout << "  Phase Idle -> Settle at " << now << std::endl;
            break;
        case BuildModelPhase::Settle:
            if (now - buildModelLastStepTime >= 2000) {
                mock_calibrationSum = 0; mock_calibrationMax = 0; mock_calibrationCount = 0;
                mock_lastKnownSampleCount = systemData.getData().current_sample_count;
                buildModelLastStepTime = now;
                buildModelPhase = BuildModelPhase::Calibrate;
                std::cout << "  Phase Settle -> Calibrate at " << now << std::endl;
            }
            break;
        case BuildModelPhase::Calibrate:
            {
                SystemData d = systemData.getData();
                if (d.current_sample_count != mock_lastKnownSampleCount) {
                    mock_lastKnownSampleCount = d.current_sample_count;
                    mock_calibrationSum += d.current_mv;
                    if (d.current_mv > mock_calibrationMax) mock_calibrationMax = d.current_mv;
                    mock_calibrationCount++;
                }
                if (mock_calibrationCount >= 20) {
                    float avg = mock_calibrationSum / (float)mock_calibrationCount;
                    systemData.setCurrentZeroOffsetMv(avg);
                    mock_noiseFloorMv = (mock_calibrationMax - avg) * 2.0f;
                    if (mock_noiseFloorMv < 2.5f) mock_noiseFloorMv = 2.5f;
                    buildModelDutyCycle = 1;
                    applyDuty(buildModelDutyCycle);
                    buildModelLastStepTime = now;
                    buildModelPhase = BuildModelPhase::DetectDeadRegion;
                    std::cout << "  Phase Calibrate -> DetectDeadRegion at " << now << " (Offset " << avg << ", Noise " << mock_noiseFloorMv << ")" << std::endl;
                }
            }
            break;
        case BuildModelPhase::DetectDeadRegion:
            if (now - buildModelLastStepTime >= 250) {
                SystemData d = systemData.getData();
                float currentMv = d.current_mv - systemData.getCurrentZeroOffsetMv();
                if (currentMv > mock_noiseFloorMv) {
                    MEASURABLE_CURRENT_THRESHOLD = d.charge_current_a;
                    mock_dutyCycles.push_back(0.0f); mock_currents.push_back(0.0f);
                    mock_dutyCycles.push_back((float)buildModelDutyCycle); mock_currents.push_back(d.charge_current_a);
                    buildModelDutyCycle += 5;
                    applyDuty(buildModelDutyCycle);
                    buildModelLastStepTime = now;
                    buildModelPhase = BuildModelPhase::WaitMeasurement;
                    std::cout << "  Phase DetectDeadRegion -> WaitMeasurement at " << now << " (Duty " << buildModelDutyCycle << ", Current " << d.charge_current_a << ")" << std::endl;
                } else {
                    buildModelDutyCycle += 2;
                    if (buildModelDutyCycle > MAX_DUTY_CYCLE) {
                        std::cout << "  Phase DetectDeadRegion -> ABORTED (Max Duty reached)" << std::endl;
                        currentAppState = APP_STATE_IDLE;
                        buildModelPhase = BuildModelPhase::Idle;
                    } else {
                        applyDuty(buildModelDutyCycle);
                    }
                }
                buildModelLastStepTime = now;
            }
            break;
        case BuildModelPhase::SetDuty:
            if (buildModelDutyCycle <= MAX_DUTY_CYCLE) {
                applyDuty(buildModelDutyCycle);
                buildModelLastStepTime = now;
                buildModelPhase = BuildModelPhase::WaitMeasurement;
            } else buildModelPhase = BuildModelPhase::Finish;
            break;
        case BuildModelPhase::WaitMeasurement:
            if (now - buildModelLastStepTime >= BUILD_CURRENT_MODEL_DELAY) {
                SystemData d = systemData.getData();
                if (d.charge_current_a >= MEASURABLE_CURRENT_THRESHOLD) {
                    mock_dutyCycles.push_back((float)buildModelDutyCycle);
                    mock_currents.push_back(d.charge_current_a);
                }
                buildModelDutyCycle += 5;
                if (buildModelDutyCycle <= MAX_DUTY_CYCLE) {
                    applyDuty(buildModelDutyCycle);
                    buildModelLastStepTime = now;
                } else {
                    buildModelPhase = BuildModelPhase::Finish;
                }
            }
            break;
        case BuildModelPhase::Finish:
            if (mock_dutyCycles.size() >= 2) {
                int degree = 3;
                AdvancedPolynomialFitter fitter;
                std::vector<float> coeffs = fitter.fitPolynomialLebesgue(mock_dutyCycles, mock_currents, degree);

                currentModel.coefficients.resize(coeffs.size());
                for (size_t i = 0; i < (size_t)coeffs.size(); ++i) {
                    currentModel.coefficients(i) = coeffs[i];
                }

                if (degree >= 0) currentModel.coefficients(0) = 0.0;
                currentModel.isModelBuilt = true;
                applyDuty(0);
                currentAppState = APP_STATE_IDLE; // Reset to idle
                startCharging(); // Auto start charging as in .ino
            } else {
                std::cout << "  Phase Finish -> ABORTED (Not enough points: " << mock_dutyCycles.size() << ")" << std::endl;
                currentAppState = APP_STATE_IDLE;
            }
            buildModelPhase = BuildModelPhase::Idle;
            std::cout << "  Phase Finish at " << now << " (Built: " << currentModel.isModelBuilt << ", Points: " << mock_dutyCycles.size() << ")" << std::endl;
            break;
    }
}

float estimateCurrent(int duty) {
    if (!currentModel.isModelBuilt) return sim.getCurrent(duty);
    double sum = 0.0;
    for (int i = 0; i < currentModel.coefficients.size(); ++i) sum += currentModel.coefficients(i) * std::pow((float)duty, i);
    return (float)std::max(0.0, sum);
}

int estimateDutyCycleForCurrent(float targetCurrent) {
    int bestDC = 0;
    float closestCurrentDiff = std::numeric_limits<float>::max();
    for (int dc = MIN_CHARGE_DUTY_CYCLE; dc <= MAX_CHARGE_DUTY_CYCLE; ++dc) {
        float estimated = estimateCurrent(dc);
        float diff = std::abs(estimated - targetCurrent);
        if (diff < closestCurrentDiff) { closestCurrentDiff = diff; bestDC = dc; }
    }
    return bestDC;
}

void reset_globals() {
    mock_millis = 0; voltage_mv = 1000.0f; current_ma = 0.0f; mAh_charged = 0.0;
    dutyCycle = 0; chargingState = CHARGE_IDLE; chargeLog.clear();
    sim = BatterySim(); overtemp_trip_counter = 0; currentAppState = APP_STATE_IDLE;
    currentIRState = IR_STATE_IDLE; isMeasuringResistance = false; isCharging = false;
    currentModel.isModelBuilt = false;
    server.args.clear();
    homeScreen.begin();
    resistanceDataCount = 0;
    resistanceDataCountPairs = 0;
    mock_sample_count = 0;
    for (int i = 0; i < PLOT_WIDTH; i++) {
        temp1_values[i] = NAN;
        temp2_values[i] = NAN;
        diff_values[i] = NAN;
        voltage_values[i] = NAN;
        current_values[i] = NAN;
    }
    for (int i=0; i<ADC_CH_COUNT; i++) {
        systemData._lastSnapshots[i].sum = 0;
        systemData._lastSnapshots[i].count = 0;
    }
}

void test_model_accuracy() {
    std::cout << "Running test_model_accuracy..." << std::endl;
    reset_globals();
    currentAppState = APP_STATE_BUILDING_MODEL;
    buildModelPhase = BuildModelPhase::Idle;
    int safety_counter = 0;
    while (safety_counter++ < 1000000) {
        mock_millis += 10;
        mock_sample_count++;
        systemData.update();
        if (currentAppState == APP_STATE_BUILDING_MODEL) {
            buildCurrentModelStep();
        } else {
            break;
        }
    }
    if (!currentModel.isModelBuilt) {
        std::cout << "FAILED: Model not built. Phase: " << (int)buildModelPhase << ", Points: " << mock_dutyCycles.size() << std::endl;
        assert(false);
    }
    float sum_sq_error = 0;
    int count = 0;
    for (int dc = 0; dc <= 255; dc += 10) {
        float actual = sim.getCurrent(dc);
        float estimated = estimateCurrent(dc);
        float error = actual - estimated;
        sum_sq_error += error * error;
        count++;
    }
    float rmse = std::sqrt(sum_sq_error / count);
    std::cout << "  RMSE: " << rmse << std::endl;
    assert(rmse < 0.05);

    // Test inverse mapping
    float target = 1.0f;
    int dc = estimateDutyCycleForCurrent(target);
    float est = estimateCurrent(dc);
    std::cout << "  Target 1.0A -> Duty " << dc << " -> Estimated " << est << "A" << std::endl;
    assert(std::abs(est - target) < 0.05);

    std::cout << "test_model_accuracy PASSED" << std::endl << std::endl;
}

void test_overtemp_shutdown() {
    std::cout << "Running test_overtemp_shutdown..." << std::endl;
    reset_globals();
    currentAppState = APP_STATE_CHARGING;
    chargingState = CHARGE_MONITOR;

    // Simulate battery heating up rapidly
    sim.temp = 50.0f;

    int loop_count = 0;
    while (loop_count++ < 1000) {
        mock_millis += CHARGE_EVALUATION_INTERVAL_MS;
        mock_sample_count++;
        systemData.update();
        chargeBattery();
        if (chargingState == CHARGE_STOPPED) break;
    }

    assert(chargingState == CHARGE_STOPPED);
    std::cout << "  Shutdown triggered at millis: " << mock_millis << std::endl;
    std::cout << "test_overtemp_shutdown PASSED" << std::endl << std::endl;
}

void test_ir_measurement() {
    std::cout << "Running test_ir_measurement..." << std::endl;
    reset_globals();
    currentAppState = APP_STATE_MEASURING_IR;
    currentIRState = IR_STATE_START;

    int loop_count = 0;
    while (currentAppState == APP_STATE_MEASURING_IR && loop_count++ < 1000000) {
        mock_millis += 50;
        mock_sample_count++;
        sim.update(0.05f, (int)dutyCycle);
        systemData.update();
        measureInternalResistanceStep();
        if (currentIRState == IR_STATE_IDLE) currentAppState = APP_STATE_IDLE;
    }

    assert(currentAppState == APP_STATE_IDLE);
    assert(resistanceDataCountPairs > 0);
    std::cout << "  Pairs measured: " << resistanceDataCountPairs << ", Slope: " << regressedInternalResistancePairsSlope << ", Intercept: " << regressedInternalResistancePairsIntercept << std::endl;
    std::cout << "test_ir_measurement PASSED" << std::endl << std::endl;
}

void test_dead_region_detection() {
    std::cout << "Running test_dead_region_detection (Offset = 150mV)..." << std::endl;
    reset_globals();
    // Simulate a high offset in the simulator
    systemData.setCurrentZeroOffsetMv(150.0f);

    currentAppState = APP_STATE_BUILDING_MODEL;
    buildModelPhase = BuildModelPhase::Idle;

    int safety_counter = 0;
    while (safety_counter++ < 1000000) {
        mock_millis += 10;
        mock_sample_count++;
        systemData.update();
        if (currentAppState == APP_STATE_BUILDING_MODEL) {
            buildCurrentModelStep();
        } else {
            break;
        }
    }

    assert(currentModel.isModelBuilt);
    std::cout << "  Calibrated Offset: " << systemData.getCurrentZeroOffsetMv() << " mV, Threshold: " << MEASURABLE_CURRENT_THRESHOLD << " A" << std::endl;
    std::cout << "test_dead_region_detection PASSED" << std::endl << std::endl;
}

void test_full_flow() {
    std::cout << "Running test_full_flow (Build Model -> Charge)..." << std::endl;
    reset_globals();
    currentAppState = APP_STATE_BUILDING_MODEL;
    buildModelPhase = BuildModelPhase::Idle;

    int loop_count = 0;
    while (loop_count++ < 200000) {
        mock_millis += 100;
        mock_sample_count++;
        sim.update(0.1f, (int)dutyCycle);
        systemData.update();

        if (currentAppState == APP_STATE_BUILDING_MODEL) {
            buildCurrentModelStep();
        } else if (currentAppState == APP_STATE_CHARGING) {
            if (mock_millis - lastChargingHouseTime >= CHARGING_HOUSEKEEP_INTERVAL) {
                lastChargingHouseTime = mock_millis;
                chargeBattery();
            }
        }

        if (currentAppState == APP_STATE_CHARGING && chargingState == CHARGE_MONITOR && mAh_charged > 100) break;
    }

    assert(currentAppState == APP_STATE_CHARGING);
    assert(chargingState == CHARGE_MONITOR);
    assert(mAh_charged > 100);
    std::cout << "Successfully transitioned from model building to active charging." << std::endl;
    std::cout << "test_full_flow PASSED" << std::endl << std::endl;
}

int main() {
    test_model_accuracy();
    test_dead_region_detection();
    test_ir_measurement();
    test_overtemp_shutdown();
    test_full_flow();
    std::cout << "ALL TESTS PASSED!" << std::endl;
    return 0;
}
